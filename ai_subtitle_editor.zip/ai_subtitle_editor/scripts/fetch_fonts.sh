#!/usr/bin/env bash
# Downloads open-licence (OFL) Khmer fonts from the google/fonts repository.
# Used by the app (assets/fonts) and by the backend (fonts/ for FFmpeg burn-in).
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p app/assets/fonts backend/fonts
B="https://github.com/google/fonts/raw/main/ofl"
get() { curl -fsSL "$1" -o "app/assets/fonts/$2" && cp "app/assets/fonts/$2" "backend/fonts/$2"; echo "ok $2"; }
get "$B/battambang/Battambang-Regular.ttf" Battambang-Regular.ttf
get "$B/siemreap/Siemreap-Regular.ttf" Siemreap-Regular.ttf
get "$B/moul/Moul-Regular.ttf" Moul-Regular.ttf
get "$B/notosanskhmer/NotoSansKhmer%5Bwdth%2Cwght%5D.ttf" NotoSansKhmer.ttf
