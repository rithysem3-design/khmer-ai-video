"""Adds INTERNET permission and allows http:// backends (LAN/dev) to the generated AndroidManifest."""
import re, sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
if "usesCleartextTraffic" not in s:
    s = re.sub(r"<application", '<application android:usesCleartextTraffic="true"', s, count=1)
open(p, "w", encoding="utf-8").write(s)
print("manifest patched")
