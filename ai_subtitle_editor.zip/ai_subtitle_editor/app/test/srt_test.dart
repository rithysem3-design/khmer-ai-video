import 'package:flutter_test/flutter_test.dart';
import 'package:subtitle_editor/srt.dart';

void main() {
  const khmer = '1\n00:00:01,000 --> 00:00:02,500\nសួស្តី ពិភពលោក\n\n2\n00:00:03,000 --> 00:00:04,000\na\nb\n';

  test('parse Khmer and roundtrip', () {
    final s = parseSrt(khmer);
    expect(s.length, 2);
    expect(s[0].text, 'សួស្តី ពិភពលោក');
    expect(s[1].text, 'a\nb');
    final again = parseSrt(toSrt(s));
    expect(again[0].start, 1000);
    expect(again[0].text, s[0].text);
  });

  test('invalid input throws', () {
    expect(() => parseSrt(''), throwsA(isA<SrtException>()));
    expect(() => parseSrt('1\nabc --> def\nx'), throwsA(isA<SrtException>()));
    expect(() => parseSrt('1\n00:00:05,000 --> 00:00:01,000\nx'), throwsA(isA<SrtException>()));
  });

  test('time formatting', () {
    expect(formatTime(3723004), '01:02:03,004');
    expect(parseTime('01:02:03,004'), 3723004);
    expect(shortTime(2000), '00:02');
  });

  test('validate overlap', () {
    expect(validate([Seg(0, 1000, 'a'), Seg(500, 2000, 'b')]), isNotNull);
    expect(validate([Seg(0, 1000, 'a'), Seg(1000, 2000, 'b')]), isNull);
  });
}
