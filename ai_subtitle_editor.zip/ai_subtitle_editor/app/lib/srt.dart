class Seg {
  int start; // ms
  int end;
  String text;
  String speaker; // 'Male' | 'Female'
  Seg(this.start, this.end, this.text, {this.speaker = 'Male'});
  Seg copy() => Seg(start, end, text, speaker: speaker);
  Map<String, dynamic> toJson() =>
      {'s': start, 'e': end, 't': text, 'sp': speaker};
  factory Seg.fromJson(Map<String, dynamic> j) =>
      Seg(j['s'], j['e'], j['t'], speaker: j['sp'] ?? 'Male');
}

class SrtException implements Exception {
  final String message;
  SrtException(this.message);
  @override
  String toString() => message;
}

final _timeRe = RegExp(r'^(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})$');

int parseTime(String s) {
  final m = _timeRe.firstMatch(s.trim());
  if (m == null) throw SrtException('Invalid timestamp: $s');
  final mi = int.parse(m[2]!), se = int.parse(m[3]!);
  if (mi > 59 || se > 59) throw SrtException('Invalid timestamp: $s');
  final ms = int.parse(m[4]!.padRight(3, '0'));
  return ((int.parse(m[1]!) * 60 + mi) * 60 + se) * 1000 + ms;
}

String formatTime(int ms) {
  if (ms < 0) ms = 0;
  final h = ms ~/ 3600000, m = (ms % 3600000) ~/ 60000;
  final s = (ms % 60000) ~/ 1000, r = ms % 1000;
  String p(int v, [int n = 2]) => v.toString().padLeft(n, '0');
  return '${p(h)}:${p(m)}:${p(s)},${p(r, 3)}';
}

/// Short form for the table: 00:02
String shortTime(int ms) {
  final s = ms ~/ 1000;
  return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
}

List<Seg> parseSrt(String content) {
  content = content.replaceFirst('\uFEFF', '').replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  final out = <Seg>[];
  for (final block in content.trim().split(RegExp(r'\n\s*\n'))) {
    final lines = block.split('\n');
    if (lines.isEmpty || lines[0].trim().isEmpty) continue;
    var i = lines[0].contains('-->') ? 0 : 1;
    if (i >= lines.length || !lines[i].contains('-->')) {
      throw SrtException('Missing timestamp line in block: ${block.length > 40 ? block.substring(0, 40) : block}');
    }
    final parts = lines[i].split('-->');
    final a = parseTime(parts[0]), b = parseTime(parts[1]);
    if (b <= a) throw SrtException('End must be after start: ${lines[i]}');
    out.add(Seg(a, b, lines.sublist(i + 1).join('\n').trim()));
  }
  if (out.isEmpty) throw SrtException('No subtitle segments found');
  return out;
}

String toSrt(List<Seg> segs) {
  final b = StringBuffer();
  for (var i = 0; i < segs.length; i++) {
    b.writeln('${i + 1}');
    b.writeln('${formatTime(segs[i].start)} --> ${formatTime(segs[i].end)}');
    b.writeln(segs[i].text);
    b.writeln();
  }
  return b.toString();
}

/// Returns an error message when the timeline is invalid, otherwise null.
String? validate(List<Seg> segs, {bool allowOverlap = false}) {
  for (var i = 0; i < segs.length; i++) {
    if (segs[i].end <= segs[i].start) return 'Segment ${i + 1}: end must be after start';
    if (!allowOverlap && i > 0 && segs[i].start < segs[i - 1].end) {
      return 'Segment ${i + 1} overlaps segment $i';
    }
  }
  return null;
}
