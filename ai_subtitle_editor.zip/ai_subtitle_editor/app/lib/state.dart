import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api.dart';
import 'srt.dart';

class SubStyle {
  String font = 'NotoSansKhmer';
  double size = 0.05; // fraction of video height
  Color color = Colors.white;
  bool bold = false;
  bool bg = true;
  Color bgColor = Colors.black;
  double bgOpacity = 0.6;
  double radius = 8;
  double x = 0.5, y = 0.85; // normalized center

  static const fonts = {
    'Battambang': 'Battambang',
    'Siemreap': 'Siemreap',
    'Moul': 'Moul (Muol Light style)',
    'NotoSansKhmer': 'Noto Sans Khmer',
  };
  // Name used by FFmpeg/ASS on the server (must be installed there).
  static const assNames = {
    'Battambang': 'Battambang', 'Siemreap': 'Siemreap', 'Moul': 'Moul', 'NotoSansKhmer': 'Noto Sans Khmer'};

  Map<String, dynamic> toJson() => {
        'font': font, 'size': size, 'color': color.toARGB32(), 'bold': bold, 'bg': bg,
        'bgColor': bgColor.toARGB32(), 'bgOpacity': bgOpacity, 'radius': radius, 'x': x, 'y': y};
  void load(Map<String, dynamic> j) {
    font = j['font'] ?? font; size = (j['size'] ?? size).toDouble();
    color = Color(j['color'] ?? color.toARGB32()); bold = j['bold'] ?? bold; bg = j['bg'] ?? bg;
    bgColor = Color(j['bgColor'] ?? bgColor.toARGB32());
    bgOpacity = (j['bgOpacity'] ?? bgOpacity).toDouble(); radius = (j['radius'] ?? radius).toDouble();
    x = (j['x'] ?? x).toDouble(); y = (j['y'] ?? y).toDouble();
  }
}

String hex(Color c) => '#${(c.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';

class AppState extends ChangeNotifier {
  SharedPreferences? _p;
  ThemeMode theme = ThemeMode.dark;
  String serverUrl = 'http://10.0.2.2:8000';
  String apiKey = '';
  String targetLang = 'km';
  String sourceLang = 'auto';

  String? videoPath;
  List<Seg> segs = [];
  int selected = -1;
  final style = SubStyle();
  String saveStatus = 'Saved';
  String? voiceJobId;
  bool busy = false;
  String busyLabel = '';
  double progress = 0;

  final List<String> _undo = [], _redo = [];
  Timer? _debounce;

  Api get api => Api(serverUrl, apiKey);

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    theme = ThemeMode.values[_p!.getInt('theme') ?? ThemeMode.dark.index];
    serverUrl = _p!.getString('server') ?? serverUrl;
    apiKey = _p!.getString('key') ?? '';
    targetLang = _p!.getString('target') ?? 'km';
    sourceLang = _p!.getString('source') ?? 'auto';
    videoPath = _p!.getString('video');
    final st = _p!.getString('style');
    if (st != null) style.load(jsonDecode(st));
    final d = _p!.getString('draft');
    if (d != null) segs = (jsonDecode(d) as List).map((e) => Seg.fromJson(e)).toList();
    notifyListeners();
  }

  Future<void> saveSettings() async {
    await _p?.setInt('theme', theme.index);
    await _p?.setString('server', serverUrl);
    await _p?.setString('key', apiKey);
    await _p?.setString('target', targetLang);
    await _p?.setString('source', sourceLang);
    notifyListeners();
  }

  void _autosave() {
    saveStatus = 'Saving…';
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), () async {
      await _p?.setString('draft', jsonEncode(segs.map((e) => e.toJson()).toList()));
      await _p?.setString('style', jsonEncode(style.toJson()));
      if (videoPath != null) await _p?.setString('video', videoPath!);
      saveStatus = 'Saved';
      notifyListeners();
    });
  }

  void _snapshot() {
    _undo.add(jsonEncode(segs.map((e) => e.toJson()).toList()));
    if (_undo.length > 50) _undo.removeAt(0);
    _redo.clear();
  }

  void _restore(String s) {
    segs = (jsonDecode(s) as List).map((e) => Seg.fromJson(e)).toList();
    selected = -1;
  }

  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;
  void undo() {
    if (!canUndo) return;
    _redo.add(jsonEncode(segs.map((e) => e.toJson()).toList()));
    _restore(_undo.removeLast());
    _autosave(); notifyListeners();
  }
  void redo() {
    if (!canRedo) return;
    _undo.add(jsonEncode(segs.map((e) => e.toJson()).toList()));
    _restore(_redo.removeLast());
    _autosave(); notifyListeners();
  }

  void setVideo(String p) { videoPath = p; _autosave(); notifyListeners(); }

  void setSegments(List<Seg> s) { _snapshot(); segs = s; selected = -1; _autosave(); notifyListeners(); }

  void edit(int i, {int? start, int? end, String? text, String? speaker}) {
    _snapshot();
    final s = segs[i];
    if (start != null) s.start = start;
    if (end != null) s.end = end;
    if (text != null) s.text = text;
    if (speaker != null) s.speaker = speaker;
    _autosave(); notifyListeners();
  }

  void add(int atMs) { _snapshot(); segs.add(Seg(atMs, atMs + 2000, 'New subtitle')); segs.sort((a, b) => a.start.compareTo(b.start)); _autosave(); notifyListeners(); }
  void remove(int i) { _snapshot(); segs.removeAt(i); selected = -1; _autosave(); notifyListeners(); }
  void duplicate(int i) { _snapshot(); final c = segs[i].copy(); c.start = c.end; c.end = c.start + (segs[i].end - segs[i].start); segs.insert(i + 1, c); _autosave(); notifyListeners(); }
  void split(int i) {
    final s = segs[i];
    final mid = (s.start + s.end) ~/ 2;
    final t = s.text; final h = t.length ~/ 2;
    _snapshot();
    segs[i] = Seg(s.start, mid, t.substring(0, h).trim(), speaker: s.speaker);
    segs.insert(i + 1, Seg(mid, s.end, t.substring(h).trim(), speaker: s.speaker));
    _autosave(); notifyListeners();
  }
  void mergeNext(int i) {
    if (i >= segs.length - 1) return;
    _snapshot();
    segs[i] = Seg(segs[i].start, segs[i + 1].end, '${segs[i].text} ${segs[i + 1].text}'.trim(), speaker: segs[i].speaker);
    segs.removeAt(i + 1);
    _autosave(); notifyListeners();
  }

  void styleChanged() { _autosave(); notifyListeners(); }

  int? activeAt(int ms) {
    for (var i = 0; i < segs.length; i++) {
      if (ms >= segs[i].start && ms < segs[i].end) return i;
    }
    return null;
  }

  Future<T?> run<T>(String label, Future<T> Function() f, void Function(String) onError) async {
    busy = true; busyLabel = label; progress = 0; notifyListeners();
    try {
      return await f();
    } catch (e) {
      onError('$e');
      return null;
    } finally {
      busy = false; notifyListeners();
    }
  }

  Future<void> pollJob(String id) async {
    while (true) {
      final j = await api.job(id);
      progress = (j['progress'] ?? 0).toDouble();
      notifyListeners();
      if (j['status'] == 'done') return;
      if (j['status'] == 'failed') throw ApiException(j['error'] ?? 'Job failed');
      await Future.delayed(const Duration(seconds: 1));
    }
  }
}
