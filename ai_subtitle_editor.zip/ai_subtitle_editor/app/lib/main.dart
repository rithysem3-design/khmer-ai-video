import 'package:flutter/material.dart';
import 'screens/editor.dart';
import 'state.dart';

final appState = AppState();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appState.init();
  runApp(const SubtitleApp());
}

class SubtitleApp extends StatelessWidget {
  const SubtitleApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (_, __) => MaterialApp(
        title: 'AI Subtitle Editor',
        debugShowCheckedModeBanner: false,
        themeMode: appState.theme,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF3B6EF5), fontFamilyFallback: const ['NotoSansKhmer']),
        darkTheme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorSchemeSeed: const Color(0xFF3B6EF5),
          scaffoldBackgroundColor: const Color(0xFF0B1020),
          fontFamilyFallback: const ['NotoSansKhmer'],
        ),
        home: const EditorScreen(),
      ),
    );
  }
}
