import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'srt.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class Api {
  final String base;
  final String key;
  Api(this.base, this.key);

  Map<String, String> get _h => {'x-api-key': key};
  Uri _u(String p, [Map<String, String>? q]) =>
      Uri.parse(base.replaceAll(RegExp(r'/+$'), '') + p).replace(queryParameters: q);

  Future<dynamic> _json(Future<http.Response> f) async {
    try {
      final r = await f.timeout(const Duration(seconds: 60));
      final body = utf8.decode(r.bodyBytes);
      if (r.statusCode >= 400) {
        String msg = 'HTTP ${r.statusCode}';
        try {
          final d = jsonDecode(body)['detail'];
          msg = d is Map ? '${d['message']}' : '$d';
        } catch (_) {}
        throw ApiException(msg);
      }
      return jsonDecode(body);
    } on SocketException {
      throw ApiException('Cannot reach backend. Check the server URL in Settings.');
    } on http.ClientException catch (e) {
      throw ApiException('Network error: ${e.message}');
    } on Exception catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Request failed: $e');
    }
  }

  Future<void> cleanup() async { await _json(http.post(_u('/maintenance/cleanup'), headers: _h)); }

  Future<dynamic> health() => _json(http.get(_u('/health')));
  Future<Map<String, dynamic>> diagnostics() async =>
      Map<String, dynamic>.from(await _json(http.get(_u('/health/diagnostics'), headers: _h)));

  Future<Map<String, dynamic>> voices() async =>
      Map<String, dynamic>.from(await _json(http.get(_u('/tts/voices', {'locale': 'km'}), headers: _h)));

  Future<List<String>> translate(List<String> texts, String source, String target) async {
    final r = await _json(http.post(_u('/subtitles/translate'),
        headers: {..._h, 'content-type': 'application/json'},
        body: jsonEncode({'texts': texts, 'source': source, 'target': target})));
    return List<String>.from(r['texts']);
  }

  Future<List<Seg>> transcribe(String path, String? lang) async {
    final req = http.MultipartRequest('POST', _u('/subtitles/transcribe'))
      ..headers.addAll(_h)
      ..files.add(await http.MultipartFile.fromPath('file', path));
    if (lang != null) req.fields['language'] = lang;
    final res = await http.Response.fromStream(await req.send());
    if (res.statusCode >= 400) {
      String msg = 'HTTP ${res.statusCode}';
      try { final d = jsonDecode(utf8.decode(res.bodyBytes))['detail']; msg = d is Map ? '${d['message']}' : '$d'; } catch (_) {}
      throw ApiException(msg);
    }
    final list = jsonDecode(utf8.decode(res.bodyBytes)) as List;
    return list.map((e) => Seg(e['start_ms'], e['end_ms'], e['text'])).toList();
  }

  Future<String> startTts(List<Map<String, dynamic>> segs) async =>
      (await _json(http.post(_u('/tts/generate'),
          headers: {..._h, 'content-type': 'application/json'},
          body: jsonEncode({'segments': segs}))))['job_id'];

  Future<String> startExport(String videoPath, String srt, Map<String, String> fields) async {
    final req = http.MultipartRequest('POST', _u('/video/export'))
      ..headers.addAll(_h)
      ..fields.addAll(fields)
      ..fields['srt'] = srt
      ..files.add(await http.MultipartFile.fromPath('video_file', videoPath));
    final res = await http.Response.fromStream(await req.send());
    if (res.statusCode >= 400) throw ApiException('Export rejected (HTTP ${res.statusCode})');
    return jsonDecode(res.body)['job_id'];
  }

  Future<Map<String, dynamic>> job(String id) async =>
      Map<String, dynamic>.from(await _json(http.get(_u('/jobs/$id'), headers: _h)));

  Future<void> downloadResult(String id, String dest) async {
    final res = await http.get(_u('/jobs/$id/result'), headers: _h);
    if (res.statusCode != 200) throw ApiException('Result not available');
    await File(dest).writeAsBytes(res.bodyBytes);
  }
}
