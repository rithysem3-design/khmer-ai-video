import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import '../main.dart';
import '../srt.dart';
import '../state.dart';
import 'settings.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  VideoPlayerController? _c;
  AppState get s => appState;

  @override
  void initState() {
    super.initState();
    if (s.videoPath != null && File(s.videoPath!).existsSync()) _loadVideo(s.videoPath!);
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  void _msg(String m, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(m), backgroundColor: error ? Colors.red.shade800 : null));
  }

  Future<void> _loadVideo(String path) async {
    final old = _c;
    final c = VideoPlayerController.file(File(path));
    try {
      await c.initialize();
    } catch (e) {
      _msg('Cannot play this video: $e', error: true);
      return;
    }
    c.addListener(() { if (mounted) setState(() {}); });
    setState(() => _c = c);
    await old?.dispose();
  }

  int get _pos => _c?.value.position.inMilliseconds ?? 0;

  // ---------- actions ----------
  Future<void> _upload() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.movie), title: const Text('Import video'), onTap: () => Navigator.pop(context, 'video')),
          ListTile(leading: const Icon(Icons.subtitles), title: const Text('Import .srt subtitle'), onTap: () => Navigator.pop(context, 'srt')),
        ]),
      ),
    );
    if (choice == 'video') {
      final r = await FilePicker.platform.pickFiles(type: FileType.video);
      final p = r?.files.single.path;
      if (p == null) return;
      s.setVideo(p);
      await _loadVideo(p);
    } else if (choice == 'srt') {
      final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      final f = r?.files.single;
      if (f == null) return;
      if (!f.name.toLowerCase().endsWith('.srt')) return _msg('Please choose a .srt file', error: true);
      try {
        s.setSegments(parseSrt(utf8.decode(f.bytes!)));
      } on SrtException catch (e) {
        _msg('Cannot read SRT: $e', error: true);
      } on FormatException {
        _msg('SRT must be UTF-8 encoded', error: true);
      }
    }
  }

  Future<bool> _confirm(String title, String body) async =>
      await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Continue')),
        ]),
      ) ?? false;

  Future<void> _generateSub() async {
    if (s.videoPath == null) return _msg('Import a video first', error: true);
    if (!await _confirm('Send video to server?', 'The video will be uploaded to your backend (${s.serverUrl}) for speech recognition.')) return;
    final r = await s.run('Recognizing speech…', () => s.api.transcribe(s.videoPath!, s.sourceLang == 'auto' ? null : s.sourceLang), (e) => _msg(e, error: true));
    if (r != null) s.setSegments(r);
  }

  Future<void> _translate() async {
    if (s.segs.isEmpty) return _msg('No subtitles to translate', error: true);
    String src = s.sourceLang, tgt = s.targetLang;
    const langs = {'auto': 'Auto', 'en': 'English', 'km': 'Khmer', 'zh': 'Chinese', 'th': 'Thai', 'vi': 'Vietnamese', 'ja': 'Japanese', 'ko': 'Korean', 'fr': 'French'};
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
        title: const Text('Translate subtitles'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(value: src, decoration: const InputDecoration(labelText: 'From'),
              items: [for (final e in langs.entries) DropdownMenuItem(value: e.key, child: Text(e.value))], onChanged: (v) => set(() => src = v!)),
          DropdownButtonFormField<String>(value: tgt, decoration: const InputDecoration(labelText: 'To'),
              items: [for (final e in langs.entries.where((e) => e.key != 'auto')) DropdownMenuItem(value: e.key, child: Text(e.value))], onChanged: (v) => set(() => tgt = v!)),
          const SizedBox(height: 8),
          const Text('Text is sent to your backend translation provider. You can confirm before it replaces the original.', style: TextStyle(fontSize: 12)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Translate')),
        ],
      )),
    );
    if (ok != true) return;
    s.sourceLang = src; s.targetLang = tgt; s.saveSettings();
    final out = await s.run('Translating…', () => s.api.translate(s.segs.map((e) => e.text).toList(), src, tgt), (e) => _msg(e, error: true));
    if (out == null || out.length != s.segs.length) return;
    final replace = await _confirm('Replace original text?', 'First result:\n${out.first}\n\nYou can undo this afterwards.');
    if (!replace) return;
    final copy = [for (var i = 0; i < s.segs.length; i++) Seg(s.segs[i].start, s.segs[i].end, out[i], speaker: s.segs[i].speaker)];
    s.setSegments(copy);
  }

  Future<void> _generateVoice() async {
    if (s.segs.isEmpty) return _msg('No subtitles', error: true);
    final bad = validate(s.segs, allowOverlap: true);
    if (bad != null) return _msg(bad, error: true);
    if (!await _confirm('Use online speech service?', 'edge-tts sends subtitle text to an online Microsoft service and needs internet. Continue?')) return;
    final ok = await s.run<bool>('Generating voice…', () async {
      final v = await s.api.voices();
      final list = List<Map<String, dynamic>>.from(v['voices']);
      if (list.isEmpty) throw 'No Khmer voice is currently available from edge-tts.';
      String pick(String g) => (list.firstWhere((e) => e['gender'] == g, orElse: () => list.first))['name'];
      final jid = await s.api.startTts([
        for (final e in s.segs) {'start_ms': e.start, 'end_ms': e.end, 'text': e.text, 'voice': pick(e.speaker == 'Male' ? 'Male' : 'Female')}
      ]);
      await s.pollJob(jid);
      final j = await s.api.job(jid);
      s.voiceJobId = jid;
      final w = (j['warnings'] as List).length;
      if (w > 0) _msg('$w segment(s) have speech longer than their time slot. Extend their end time.');
      return true;
    }, (e) => _msg(e, error: true));
    if (ok == true) _msg('Voice generated. Use Save → Export to include it.');
  }

  Future<String> _outDir() async {
    final d = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    return d.path;
  }

  Future<void> _save() async {
    final c = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.subtitles), title: const Text('Save .srt file'), onTap: () => Navigator.pop(context, 'srt')),
        ListTile(leading: const Icon(Icons.audiotrack), title: const Text('Save generated voice (.mp3)'), onTap: () => Navigator.pop(context, 'mp3')),
        ListTile(leading: const Icon(Icons.movie_creation), title: const Text('Export video with subtitles'), onTap: () => Navigator.pop(context, 'mp4')),
      ])),
    );
    if (c == null) return;
    final err = validate(s.segs, allowOverlap: true);
    if (err != null) return _msg(err, error: true);
    final dir = await _outDir();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    if (c == 'srt') {
      final f = File('$dir/subtitles_$stamp.srt');
      await f.writeAsString(toSrt(s.segs));
      _msg('Saved: ${f.path}');
    } else if (c == 'mp3') {
      if (s.voiceJobId == null) return _msg('Generate voice first', error: true);
      await s.run('Downloading…', () async { await s.api.downloadResult(s.voiceJobId!, '$dir/voice_$stamp.mp3'); }, (e) => _msg(e, error: true));
      _msg('Saved: $dir/voice_$stamp.mp3');
    } else {
      if (s.videoPath == null) return _msg('Import a video first', error: true);
      if (!await _confirm('Upload video for export?', 'The video is uploaded to your backend to burn in subtitles.')) return;
      final st = s.style;
      final ok = await s.run<bool>('Exporting video…', () async {
        final jid = await s.api.startExport(s.videoPath!, toSrt(s.segs), {
          'font': SubStyle.assNames[st.font]!, 'size': '${st.size}', 'color': hex(st.color), 'bold': '${st.bold}',
          'bg_enabled': '${st.bg}', 'bg_color': hex(st.bgColor), 'bg_opacity': '${st.bgOpacity}',
          'x': '${st.x}', 'y': '${st.y}',
          if (s.voiceJobId != null) 'voice_job': s.voiceJobId!,
        });
        await s.pollJob(jid);
        await s.api.downloadResult(jid, '$dir/export_$stamp.mp4');
        return true;
      }, (e) => _msg(e, error: true));
      if (ok == true) _msg('Saved: $dir/export_$stamp.mp4');
    }
  }

  void _openStyle() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => ListenableBuilder(listenable: s, builder: (ctx, _) => _StylePanel(s)),
    );
  }

  void _editSeg(int i) {
    s.selected = i;
    _c?.seekTo(Duration(milliseconds: s.segs[i].start));
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => _SegEditor(i, s, _msg));
  }

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: Row(children: [const Text('Untitled project', style: TextStyle(fontSize: 16)), const SizedBox(width: 8),
            Text(s.saveStatus, style: const TextStyle(fontSize: 11, color: Colors.grey))]),
          actions: [
            IconButton(icon: const Icon(Icons.undo), onPressed: s.canUndo ? s.undo : null),
            IconButton(icon: const Icon(Icons.redo), onPressed: s.canRedo ? s.redo : null),
          ],
        ),
        body: SafeArea(
          child: Stack(children: [
            Column(children: [
              SizedBox(height: MediaQuery.of(context).size.height * 0.35, child: _preview()),
              _toolbar(),
              Expanded(child: _table()),
              _bottomButtons(),
            ]),
            if (s.busy) _busyOverlay(),
          ]),
        ),
      ),
    );
  }

  Widget _preview() {
    final c = _c;
    final active = s.selected >= 0 && s.selected < s.segs.length ? s.selected : s.activeAt(_pos);
    return Container(
      color: Colors.black,
      child: Stack(children: [
        Center(
          child: c == null
              ? const Text('Import a video to start', style: TextStyle(color: Colors.white54))
              : AspectRatio(
                  aspectRatio: c.value.aspectRatio,
                  child: LayoutBuilder(builder: (ctx, box) {
                    final h = box.maxHeight, w = box.maxWidth;
                    final st = s.style;
                    return Stack(children: [
                      VideoPlayer(c),
                      if (active != null)
                        Positioned(
                          left: st.x * w, top: st.y * h,
                          child: FractionalTranslation(
                            translation: const Offset(-0.5, -0.5),
                            child: GestureDetector(
                              onPanUpdate: (d) {
                                st.x = (st.x + d.delta.dx / w).clamp(0.0, 1.0);
                                st.y = (st.y + d.delta.dy / h).clamp(0.0, 1.0);
                                s.styleChanged();
                              },
                              child: Container(
                                constraints: BoxConstraints(maxWidth: w * 0.9),
                                padding: EdgeInsets.symmetric(horizontal: st.size * h * 0.4, vertical: st.size * h * 0.2),
                                decoration: BoxDecoration(
                                  color: st.bg ? st.bgColor.withValues(alpha: st.bgOpacity) : null,
                                  borderRadius: BorderRadius.circular(st.radius),
                                  border: Border.all(color: Colors.white24),
                                ),
                                child: Text(s.segs[active].text, textAlign: TextAlign.center,
                                    style: TextStyle(fontFamily: st.font, fontSize: st.size * h, color: st.color,
                                        fontWeight: st.bold ? FontWeight.bold : FontWeight.normal,
                                        shadows: st.bg ? null : const [Shadow(blurRadius: 3)])),
                              ),
                            ),
                          ),
                        ),
                    ]);
                  }),
                ),
        ),
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Container(
            color: Colors.black38,
            child: Row(children: [
              IconButton(
                icon: Icon(c?.value.isPlaying == true ? Icons.pause : Icons.play_arrow, color: Colors.white),
                onPressed: c == null ? null : () => c.value.isPlaying ? c.pause() : c.play(),
              ),
              Expanded(
                child: Slider(
                  activeColor: Colors.orange,
                  value: c == null ? 0 : _pos.clamp(0, c.value.duration.inMilliseconds).toDouble(),
                  max: c == null ? 1 : c.value.duration.inMilliseconds.toDouble().clamp(1, double.infinity),
                  onChanged: c == null ? null : (v) => c.seekTo(Duration(milliseconds: v.toInt())),
                ),
              ),
              Text('${shortTime(_pos)} / ${shortTime(c?.value.duration.inMilliseconds ?? 0)}', style: const TextStyle(color: Colors.white, fontSize: 12)),
              const SizedBox(width: 8),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _toolBtn(IconData i, String label, VoidCallback f) => Expanded(
        child: Padding(
          padding: const EdgeInsets.all(3),
          child: Material(
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: f,
              child: Padding(padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(i, size: 22), const SizedBox(height: 2), Text(label, style: const TextStyle(fontSize: 10), maxLines: 1)])),
            ),
          ),
        ),
      );

  Widget _toolbar() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(children: [
          _toolBtn(Icons.cloud_upload_outlined, 'Upload File', _upload),
          _toolBtn(Icons.auto_fix_high, 'Generate Sub', _generateSub),
          _toolBtn(Icons.translate, 'Translate', _translate),
          _toolBtn(Icons.text_fields, 'Text', _openStyle),
          _toolBtn(Icons.settings_outlined, 'Settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ]),
      );

  Widget _table() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white12)),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(children: const [
            SizedBox(width: 24, child: Text('#')), SizedBox(width: 42, child: Text('Start')), SizedBox(width: 42, child: Text('End')),
            Expanded(child: Center(child: Text('Subtitle'))), SizedBox(width: 118, child: Center(child: Text('Speaker'))),
          ]),
        ),
        const Divider(height: 1),
        Expanded(
          child: s.segs.isEmpty
              ? const Center(child: Text('No subtitles yet.\nImport an .srt or use Generate Sub.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)))
              : ListView.builder(
                  itemCount: s.segs.length,
                  itemBuilder: (_, i) {
                    final g = s.segs[i];
                    final on = i == s.selected || i == s.activeAt(_pos);
                    return InkWell(
                      onTap: () => _editSeg(i),
                      child: Container(
                        color: on ? Colors.blue.withValues(alpha: 0.12) : null,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: Row(children: [
                          SizedBox(width: 24, child: Text('${i + 1}'.padLeft(2, '0'), style: const TextStyle(fontSize: 11))),
                          SizedBox(width: 42, child: Text(shortTime(g.start), style: const TextStyle(fontSize: 11))),
                          SizedBox(width: 42, child: Text(shortTime(g.end), style: const TextStyle(fontSize: 11))),
                          Expanded(child: Text(g.text, style: const TextStyle(fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis)),
                          _spk(i, 'Male'), const SizedBox(width: 4), _spk(i, 'Female'),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  Widget _spk(int i, String v) {
    final on = s.segs[i].speaker == v;
    return GestureDetector(
      onTap: () => s.edit(i, speaker: v),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        decoration: BoxDecoration(color: on ? const Color(0xFF1B3F94) : Colors.white10, borderRadius: BorderRadius.circular(8)),
        child: Text(v, style: const TextStyle(fontSize: 11)),
      ),
    );
  }

  Widget _bottomButtons() => Padding(
        padding: const EdgeInsets.all(10),
        child: Row(children: [
          Expanded(
            flex: 6,
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: const LinearGradient(colors: [Color(0xFF7B2FBE), Color(0xFF1E9BE8)])),
              child: TextButton.icon(
                onPressed: _generateVoice,
                icon: const Icon(Icons.auto_awesome, color: Colors.white),
                label: const Text('Generate', style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(flex: 5, child: OutlinedButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: const Text('Save'))),
        ]),
      );

  Widget _busyOverlay() => Container(
        color: Colors.black54,
        child: Center(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(s.busyLabel), const SizedBox(height: 12),
                SizedBox(width: 200, child: LinearProgressIndicator(value: s.progress > 0 ? s.progress : null)),
              ]),
            ),
          ),
        ),
      );
}

// ---------- segment editor sheet ----------
class _SegEditor extends StatefulWidget {
  final int i;
  final AppState s;
  final void Function(String, {bool error}) msg;
  const _SegEditor(this.i, this.s, this.msg);
  @override
  State<_SegEditor> createState() => _SegEditorState();
}

class _SegEditorState extends State<_SegEditor> {
  late final text = TextEditingController(text: widget.s.segs[widget.i].text);
  late final st = TextEditingController(text: formatTime(widget.s.segs[widget.i].start));
  late final en = TextEditingController(text: formatTime(widget.s.segs[widget.i].end));

  void _apply() {
    try {
      final a = parseTime(st.text), b = parseTime(en.text);
      if (b <= a) throw SrtException('End must be after start');
      widget.s.edit(widget.i, start: a, end: b, text: text.text);
      Navigator.pop(context);
    } on SrtException catch (e) {
      widget.msg('$e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.i, s = widget.s;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Expanded(child: TextField(controller: st, decoration: const InputDecoration(labelText: 'Start (HH:MM:SS,mmm)'))),
          const SizedBox(width: 12),
          Expanded(child: TextField(controller: en, decoration: const InputDecoration(labelText: 'End'))),
        ]),
        const SizedBox(height: 8),
        TextField(controller: text, maxLines: 3, style: const TextStyle(fontFamily: 'NotoSansKhmer'), decoration: const InputDecoration(labelText: 'Subtitle text', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          ActionChip(avatar: const Icon(Icons.copy, size: 16), label: const Text('Duplicate'), onPressed: () { s.duplicate(i); Navigator.pop(context); }),
          ActionChip(avatar: const Icon(Icons.call_split, size: 16), label: const Text('Split'), onPressed: () { s.split(i); Navigator.pop(context); }),
          ActionChip(avatar: const Icon(Icons.call_merge, size: 16), label: const Text('Merge next'), onPressed: () { s.mergeNext(i); Navigator.pop(context); }),
          ActionChip(avatar: const Icon(Icons.add, size: 16), label: const Text('Add after'), onPressed: () { s.add(s.segs[i].end); Navigator.pop(context); }),
          ActionChip(avatar: const Icon(Icons.delete_outline, size: 16), label: const Text('Delete'), onPressed: () { s.remove(i); Navigator.pop(context); }),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel'))),
          Expanded(child: FilledButton(onPressed: _apply, child: const Text('Apply'))),
        ]),
        const SizedBox(height: 12),
      ]),
    );
  }
}

// ---------- style panel ----------
class _StylePanel extends StatelessWidget {
  final AppState s;
  const _StylePanel(this.s);
  static const colors = [Colors.white, Colors.yellow, Colors.orange, Colors.cyanAccent, Colors.greenAccent, Colors.pinkAccent, Colors.black];

  @override
  Widget build(BuildContext context) {
    final st = s.style;
    Widget swatches(Color cur, void Function(Color) set) => Wrap(spacing: 8, children: [
          for (final c in colors)
            GestureDetector(
              onTap: () { set(c); s.styleChanged(); },
              child: CircleAvatar(radius: 14, backgroundColor: c, child: cur.toARGB32() == c.toARGB32() ? Icon(Icons.check, size: 16, color: c == Colors.white ? Colors.black : Colors.white) : null),
            ),
        ]);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Khmer font', style: TextStyle(fontWeight: FontWeight.bold)),
          for (final e in SubStyle.fonts.entries)
            RadioListTile<String>(
              dense: true, value: e.key, groupValue: st.font,
              onChanged: (v) { st.font = v!; s.styleChanged(); },
              title: Text(e.value, style: const TextStyle(fontSize: 12)),
              subtitle: Text('សួស្តី ពិភពលោក', style: TextStyle(fontFamily: e.key, fontSize: 18)),
            ),
          const Text('Size'),
          Slider(value: st.size, min: 0.03, max: 0.12, onChanged: (v) { st.size = v; s.styleChanged(); }),
          const Text('Text color'),
          swatches(st.color, (c) => st.color = c),
          SwitchListTile(dense: true, title: const Text('Bold'), value: st.bold, onChanged: (v) { st.bold = v; s.styleChanged(); }),
          SwitchListTile(dense: true, title: const Text('Background'), value: st.bg, onChanged: (v) { st.bg = v; s.styleChanged(); }),
          if (st.bg) ...[
            const Text('Background color'),
            swatches(st.bgColor, (c) => st.bgColor = c),
            const Text('Background opacity'),
            Slider(value: st.bgOpacity, onChanged: (v) { st.bgOpacity = v; s.styleChanged(); }),
            const Text('Corner radius (preview only; export uses square box)'),
            Slider(value: st.radius, max: 30, onChanged: (v) { st.radius = v; s.styleChanged(); }),
          ],
          Row(children: [
            TextButton(onPressed: () { st.x = 0.5; st.y = 0.85; s.styleChanged(); }, child: const Text('Reset position')),
            TextButton(onPressed: () { st.x = 0.5; s.styleChanged(); }, child: const Text('Center horizontally')),
          ]),
          const Text('Tip: drag the subtitle on the video to move it.', style: TextStyle(fontSize: 12, color: Colors.grey)),
        ]),
      ),
    );
  }
}
