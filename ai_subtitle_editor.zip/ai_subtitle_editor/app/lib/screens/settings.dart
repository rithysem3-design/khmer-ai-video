import 'package:flutter/material.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final url = TextEditingController(text: appState.serverUrl);
  late final key = TextEditingController(text: appState.apiKey);
  Map<String, dynamic>? diag;
  String? diagError;
  bool checking = false;

  Future<void> _check() async {
    appState.serverUrl = url.text.trim();
    appState.apiKey = key.text.trim();
    await appState.saveSettings();
    setState(() { checking = true; diag = null; diagError = null; });
    try {
      await appState.api.health();
      diag = await appState.api.diagnostics();
    } catch (e) {
      diagError = '$e';
    }
    if (mounted) setState(() => checking = false);
  }

  Color _c(String s) => switch (s) {
        'Healthy' => Colors.green,
        'Warning' => Colors.orange,
        'Failed' => Colors.red,
        _ => Colors.grey,
      };

  Future<void> _cleanup() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear server temporary files?'),
        content: const Text('Removes only temporary job files on the backend (generated voice, exports in progress). Your videos, SRT files and saved exports on this phone are not touched.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await appState.api.cleanup();
      appState.voiceJobId = null;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Temporary files cleared')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Theme', style: TextStyle(fontWeight: FontWeight.bold)),
        SegmentedButton<ThemeMode>(
          segments: const [
            ButtonSegment(value: ThemeMode.dark, label: Text('Dark')),
            ButtonSegment(value: ThemeMode.light, label: Text('Light')),
            ButtonSegment(value: ThemeMode.system, label: Text('System')),
          ],
          selected: {appState.theme},
          onSelectionChanged: (v) { appState.theme = v.first; appState.saveSettings(); setState(() {}); },
        ),
        const SizedBox(height: 20),
        const Text('Backend', style: TextStyle(fontWeight: FontWeight.bold)),
        TextField(controller: url, decoration: const InputDecoration(labelText: 'Server URL (e.g. http://192.168.1.10:8000)')),
        TextField(controller: key, obscureText: true, decoration: const InputDecoration(labelText: 'API key (if server uses one)')),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: checking ? null : _check, icon: const Icon(Icons.health_and_safety), label: const Text('Check Now')),
        if (checking) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
        if (diagError != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text('Failed: $diagError', style: const TextStyle(color: Colors.redAccent))),
        if (diag != null)
          for (final e in diag!.entries)
            ListTile(
              dense: true,
              leading: Icon(Icons.circle, color: _c(e.value['status']), size: 14),
              title: Text('${e.key}: ${e.value['status']}'),
              subtitle: (e.value['hint'] ?? '').toString().isEmpty ? null : Text(e.value['hint']),
            ),
        const Divider(height: 32),
        OutlinedButton.icon(onPressed: _cleanup, icon: const Icon(Icons.cleaning_services), label: const Text('Clear server temp files')),
        const SizedBox(height: 20),
        const Text('Privacy', style: TextStyle(fontWeight: FontWeight.bold)),
        const Text('Videos and subtitle text are only sent to your own backend when you use Generate Sub, Translate, Generate voice or Export. '
            'The edge-tts voice service is online (Microsoft) and needs internet.', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 12),
        const Text('Version 0.1.0', style: TextStyle(color: Colors.grey)),
      ]),
    );
  }
}
