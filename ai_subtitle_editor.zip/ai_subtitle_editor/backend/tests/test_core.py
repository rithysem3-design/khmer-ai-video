import pytest

from app.services.ass import Style, build_ass
from app.services.srt import SrtError, format_time, parse_srt, parse_time, to_srt

KHMER = "1\n00:00:01,000 --> 00:00:02,500\nសួស្តី ពិភពលោក\n\n2\n00:00:03,000 --> 00:00:04,000\nline1\nline2\n"


def test_parse_khmer_roundtrip():
    segs = parse_srt(KHMER)
    assert segs[0].text == "សួស្តី ពិភពលោក"
    assert segs[1].text == "line1\nline2"
    assert parse_srt(to_srt(segs)) == segs


def test_bom_and_crlf():
    assert len(parse_srt("\ufeff" + KHMER.replace("\n", "\r\n"))) == 2


@pytest.mark.parametrize("bad", ["", "1\nabc --> def\nx", "1\n00:00:05,000 --> 00:00:01,000\nx",
                                 "1\n00:99:00,000 --> 00:99:01,000\nx"])
def test_invalid(bad):
    with pytest.raises(SrtError):
        parse_srt(bad)


def test_time():
    assert parse_time("01:02:03,004") == 3723004
    assert format_time(3723004) == "01:02:03,004"


def test_ass_position_and_style():
    segs = parse_srt(KHMER)
    ass = build_ass(segs, Style(x=0.5, y=0.5, bg_enabled=True, bg_opacity=1.0), 1000, 2000)
    assert "\\pos(500,1000)" in ass
    assert "សួស្តី ពិភពលោក" in ass
    assert "line1\\Nline2" in ass
    assert "BorderStyle" in ass and ",3,6," in ass


def test_ass_clamps_position():
    ass = build_ass(parse_srt(KHMER), Style(x=5, y=-2), 100, 100)
    assert "\\pos(100,0)" in ass
