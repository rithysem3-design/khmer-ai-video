import asyncio
import os
import shutil
import tempfile
import threading
import uuid

from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .services import tts, video
from .services.ass import Style, build_ass
from .services.srt import Segment, SrtError, parse_srt, to_srt
from .services.translation import ProviderError, ProviderNotConfigured, get_provider

API_KEY = os.getenv("API_KEY", "")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
WORK = os.path.join(tempfile.gettempdir(), "subtitle_editor_jobs")
os.makedirs(WORK, exist_ok=True)

app = FastAPI(title="AI Subtitle Editor API", version="0.1.0")
JOBS: dict[str, dict] = {}
_lock = threading.Lock()


def auth(x_api_key: str = Header(default="")):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(401, "Invalid API key")


def err(code: str, msg: str, status: int = 400):
    raise HTTPException(status, {"code": code, "message": msg})


# ---------- health ----------
@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/health/diagnostics", dependencies=[Depends(auth)])
async def diagnostics():
    res = {}
    res["ffmpeg"] = {"status": "Healthy" if shutil.which("ffmpeg") and shutil.which("ffprobe") else "Failed",
                     "hint": "Install FFmpeg on the server" if not shutil.which("ffmpeg") else ""}
    try:
        v = await tts.list_voices("km")
        res["tts_khmer"] = {"status": "Healthy" if v else "Warning",
                            "hint": "" if v else "No Khmer voice currently offered by edge-tts"}
    except tts.TtsUnavailable as e:
        res["tts_khmer"] = {"status": "Failed", "hint": str(e)}
    p = get_provider() if os.getenv("TRANSLATE_PROVIDER", "libretranslate") else None
    res["translation"] = {"status": "Healthy" if p and p.is_configured() else "Not Configured",
                          "hint": "" if p and p.is_configured() else "Set LIBRETRANSLATE_URL"}
    try:
        import faster_whisper  # noqa: F401
        res["transcription"] = {"status": "Healthy", "hint": ""}
    except ImportError:
        res["transcription"] = {"status": "Not Configured", "hint": "pip install faster-whisper"}
    free = shutil.disk_usage(WORK).free // 2**20
    res["storage"] = {"status": "Healthy" if free > 500 else "Warning", "hint": f"{free} MB free"}
    return res


@app.post("/maintenance/cleanup", dependencies=[Depends(auth)])
def cleanup():
    """Safe repair: removes only this server's temporary job files."""
    n = 0
    for d in os.listdir(WORK):
        shutil.rmtree(os.path.join(WORK, d), ignore_errors=True)
        n += 1
    JOBS.clear()
    return {"removed": n}


# ---------- subtitles ----------
class SrtIn(BaseModel):
    content: str = Field(max_length=2_000_000)


@app.post("/subtitles/parse", dependencies=[Depends(auth)])
def parse(body: SrtIn):
    try:
        segs = parse_srt(body.content)
    except SrtError as e:
        err("SRT_INVALID", str(e), 422)
    return [s.__dict__ for s in segs]


class TranslateIn(BaseModel):
    texts: list[str] = Field(max_length=2000)
    source: str = "auto"
    target: str = "km"
    provider: str | None = None


@app.post("/subtitles/translate", dependencies=[Depends(auth)])
async def translate(body: TranslateIn):
    try:
        p = get_provider(body.provider)
        return {"texts": await p.translate(body.texts, body.source, body.target)}
    except ProviderNotConfigured as e:
        err("NOT_CONFIGURED", str(e), 503)
    except ProviderError as e:
        err("PROVIDER_ERROR", str(e), 502)


@app.post("/subtitles/transcribe", dependencies=[Depends(auth)])
async def transcribe(file: UploadFile = File(...), language: str | None = Form(None)):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        err("NOT_CONFIGURED", "faster-whisper is not installed on the server", 503)
    path = await _save_upload(file, WORK)
    try:
        model = WhisperModel(os.getenv("WHISPER_MODEL", "small"), compute_type="int8")
        segs, _ = await asyncio.to_thread(lambda: (lambda s, i: (list(s), i))(*model.transcribe(path, language=language)))
        return [{"index": i + 1, "start_ms": int(s.start * 1000), "end_ms": int(s.end * 1000), "text": s.text.strip()}
                for i, s in enumerate(segs)]
    finally:
        os.remove(path)


# ---------- tts ----------
@app.get("/tts/voices", dependencies=[Depends(auth)])
async def voices(locale: str = "km"):
    try:
        v = await tts.list_voices(locale)
    except tts.TtsUnavailable as e:
        err("TTS_UNAVAILABLE", str(e), 503)
    return {"voices": v, "available": bool(v),
            "notice": "edge-tts sends text to an online Microsoft service; internet required."}


class PreviewIn(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    voice: str
    rate: str = "+0%"
    pitch: str = "+0Hz"


@app.post("/tts/preview", dependencies=[Depends(auth)])
async def preview(body: PreviewIn):
    out = os.path.join(WORK, f"preview_{uuid.uuid4().hex}.mp3")
    try:
        await tts.synth(body.text, body.voice, out, body.rate, body.pitch)
    except tts.TtsUnavailable as e:
        err("TTS_UNAVAILABLE", str(e), 503)
    return FileResponse(out, media_type="audio/mpeg")


class SegIn(BaseModel):
    start_ms: int = Field(ge=0)
    end_ms: int = Field(gt=0)
    text: str
    voice: str


class GenIn(BaseModel):
    segments: list[SegIn] = Field(min_length=1, max_length=2000)


# ---------- jobs ----------
def _new_job(kind: str) -> str:
    jid = uuid.uuid4().hex
    with _lock:
        JOBS[jid] = {"id": jid, "kind": kind, "status": "queued", "progress": 0.0, "error": None,
                     "result": None, "warnings": [], "dir": os.path.join(WORK, jid)}
    os.makedirs(JOBS[jid]["dir"], exist_ok=True)
    return jid


@app.post("/tts/generate", dependencies=[Depends(auth)])
async def tts_generate(body: GenIn, bg: BackgroundTasks):
    jid = _new_job("tts")
    bg.add_task(_run_tts, jid, [s.model_dump() for s in body.segments])
    return {"job_id": jid}


async def _run_tts(jid, segs):
    j = JOBS[jid]
    j["status"] = "running"
    out = os.path.join(j["dir"], "voice.mp3")
    try:
        j["warnings"] = await tts.build_track(segs, out, lambda p: j.update(progress=p))
        j.update(status="done", result=out, progress=1.0)
    except Exception as e:
        j.update(status="failed", error=str(e))


@app.post("/video/export", dependencies=[Depends(auth)])
async def export(bg: BackgroundTasks, video_file: UploadFile = File(...), srt: str = Form(...),
                 font: str = Form("Noto Sans Khmer"), size: float = Form(0.05), color: str = Form("#FFFFFF"),
                 bold: bool = Form(False), bg_enabled: bool = Form(False), bg_color: str = Form("#000000"),
                 bg_opacity: float = Form(0.6), x: float = Form(0.5), y: float = Form(0.88),
                 crf: int = Form(23), voice_job: str | None = Form(None),
                 orig_vol: float = Form(1.0), voice_vol: float = Form(1.0)):
    try:
        segs = parse_srt(srt)
    except SrtError as e:
        err("SRT_INVALID", str(e), 422)
    if not 14 <= crf <= 35:
        err("BAD_PARAM", "crf must be 14..35", 422)
    jid = _new_job("export")
    path = await _save_upload(video_file, JOBS[jid]["dir"])
    audio = JOBS.get(voice_job, {}).get("result") if voice_job else None
    st = Style(font=font, size=size, color=color, bold=bold, bg_enabled=bg_enabled,
               bg_color=bg_color, bg_opacity=bg_opacity, x=x, y=y)
    bg.add_task(asyncio.to_thread, _run_export, jid, path, segs, st, audio, crf, orig_vol, voice_vol)
    return {"job_id": jid}


def _run_export(jid, path, segs, st, audio, crf, ov, vv):
    j = JOBS[jid]
    j["status"] = "running"
    try:
        info = video.probe(path)
        ass = os.path.join(j["dir"], "subs.ass")
        with open(ass, "w", encoding="utf-8") as f:
            f.write(build_ass(segs, st, info["width"], info["height"]))
        out = os.path.join(j["dir"], "output.mp4")
        video.burn(path, ass, out, audio, ov, vv, crf, os.getenv("FONTS_DIR"))
        j.update(status="done", result=out, progress=1.0)
    except Exception as e:
        j.update(status="failed", error=str(e))


async def _save_upload(f: UploadFile, folder: str) -> str:
    ext = os.path.splitext(f.filename or "")[1].lower()[:8]
    path = os.path.join(folder, uuid.uuid4().hex + ext)
    size = 0
    with open(path, "wb") as o:
        while chunk := await f.read(1 << 20):
            size += len(chunk)
            if size > MAX_UPLOAD_MB * 2**20:
                o.close(); os.remove(path)
                err("TOO_LARGE", f"Max upload {MAX_UPLOAD_MB} MB", 413)
            o.write(chunk)
    return path


@app.get("/jobs/{job_id}", dependencies=[Depends(auth)])
def job(job_id: str):
    j = JOBS.get(job_id)
    if not j:
        err("NOT_FOUND", "Unknown job", 404)
    return {k: j[k] for k in ("id", "kind", "status", "progress", "error", "warnings")}


@app.get("/jobs/{job_id}/result", dependencies=[Depends(auth)])
def job_result(job_id: str):
    j = JOBS.get(job_id)
    if not j or j["status"] != "done":
        err("NOT_READY", "Job not finished", 409)
    return FileResponse(j["result"])
