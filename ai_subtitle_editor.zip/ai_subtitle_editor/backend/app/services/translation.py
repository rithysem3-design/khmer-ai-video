"""Translation provider interface. Add providers without touching the API layer."""
import os
from abc import ABC, abstractmethod

import httpx


class ProviderNotConfigured(Exception):
    pass


class ProviderError(Exception):
    pass


class TranslationProvider(ABC):
    name = "base"

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    async def translate(self, texts: list[str], source: str, target: str) -> list[str]: ...


class LibreTranslateProvider(TranslationProvider):
    """Works with any LibreTranslate-compatible server (self-hosted or hosted)."""
    name = "libretranslate"

    def __init__(self):
        self.url = os.getenv("LIBRETRANSLATE_URL", "").rstrip("/")
        self.key = os.getenv("LIBRETRANSLATE_API_KEY", "")

    def is_configured(self) -> bool:
        return bool(self.url)

    async def translate(self, texts, source, target):
        if not self.is_configured():
            raise ProviderNotConfigured("Set LIBRETRANSLATE_URL")
        out = []
        async with httpx.AsyncClient(timeout=30) as c:
            for t in texts:
                try:
                    r = await c.post(f"{self.url}/translate", json={
                        "q": t, "source": source, "target": target, "format": "text",
                        **({"api_key": self.key} if self.key else {})})
                except httpx.HTTPError as e:
                    raise ProviderError(f"Network error: {e}") from e
                if r.status_code == 429:
                    raise ProviderError("Rate limited by provider, retry later")
                if r.status_code != 200:
                    raise ProviderError(f"Provider returned HTTP {r.status_code}")
                out.append(r.json().get("translatedText", ""))
        return out


PROVIDERS: dict[str, type[TranslationProvider]] = {"libretranslate": LibreTranslateProvider}


def get_provider(name: str | None = None) -> TranslationProvider:
    name = name or os.getenv("TRANSLATE_PROVIDER", "libretranslate")
    if name not in PROVIDERS:
        raise ProviderNotConfigured(f"Unknown provider {name}")
    return PROVIDERS[name]()
