"""edge-tts wrapper. Voices are discovered at runtime; nothing is hardcoded. Requires internet."""
import asyncio
import os
import subprocess
import tempfile

try:
    import edge_tts
except ImportError:  # pragma: no cover
    edge_tts = None


class TtsUnavailable(Exception):
    pass


async def list_voices(locale_prefix: str = "km") -> list[dict]:
    if edge_tts is None:
        raise TtsUnavailable("edge-tts is not installed")
    try:
        voices = await asyncio.wait_for(edge_tts.list_voices(), timeout=20)
    except Exception as e:
        raise TtsUnavailable(f"Cannot reach speech service: {e}") from e
    return [
        {"name": v["ShortName"], "gender": v["Gender"], "locale": v["Locale"]}
        for v in voices if v["Locale"].lower().startswith(locale_prefix.lower())
    ]


async def synth(text: str, voice: str, out_path: str, rate: str = "+0%", pitch: str = "+0Hz"):
    if edge_tts is None:
        raise TtsUnavailable("edge-tts is not installed")
    if not text.strip():
        raise ValueError("empty text")
    try:
        await asyncio.wait_for(
            edge_tts.Communicate(text, voice, rate=rate, pitch=pitch).save(out_path), timeout=60)
    except Exception as e:
        raise TtsUnavailable(f"Speech generation failed: {e}") from e


def duration_ms(path: str) -> int:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=nw=1:nk=1", path], capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        raise RuntimeError("ffprobe failed")
    return int(float(r.stdout.strip()) * 1000)


async def build_track(segments: list[dict], out_path: str, progress=lambda p: None):
    """segments: [{start_ms,end_ms,text,voice}] -> one MP3 aligned to timestamps.
    Returns warnings for segments whose speech is longer than the slot (never truncated)."""
    warnings, inputs, delays = [], [], []
    with tempfile.TemporaryDirectory() as tmp:
        for i, s in enumerate(segments):
            p = os.path.join(tmp, f"{i}.mp3")
            await synth(s["text"], s["voice"], p, s.get("rate", "+0%"), s.get("pitch", "+0Hz"))
            d = duration_ms(p)
            if d > s["end_ms"] - s["start_ms"]:
                warnings.append({"index": i + 1, "speech_ms": d, "slot_ms": s["end_ms"] - s["start_ms"]})
            inputs.append(p)
            delays.append(int(s["start_ms"]))
            progress((i + 1) / len(segments) * 0.9)
        cmd = ["ffmpeg", "-y"]
        for p in inputs:
            cmd += ["-i", p]
        fc = ";".join(f"[{i}:a]adelay={d}|{d}[a{i}]" for i, d in enumerate(delays))
        fc += ";" + "".join(f"[a{i}]" for i in range(len(inputs))) + f"amix=inputs={len(inputs)}:normalize=0[out]"
        cmd += ["-filter_complex", fc, "-map", "[out]", out_path]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg mixing failed")
    progress(1.0)
    return warnings
