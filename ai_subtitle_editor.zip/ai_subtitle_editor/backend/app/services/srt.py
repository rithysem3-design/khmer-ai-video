"""SRT parsing / export (pure Python, UTF-8 safe for Khmer)."""
import re
from dataclasses import dataclass

TIME_RE = re.compile(r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})")
LINE_RE = re.compile(r"^\s*(\S+)\s*-->\s*(\S+)")


class SrtError(ValueError):
    pass


@dataclass
class Segment:
    index: int
    start_ms: int
    end_ms: int
    text: str


def parse_time(s: str) -> int:
    m = TIME_RE.fullmatch(s.strip())
    if not m:
        raise SrtError(f"Invalid timestamp: {s!r}")
    h, mi, se, ms = m.groups()
    if int(mi) > 59 or int(se) > 59:
        raise SrtError(f"Invalid timestamp: {s!r}")
    return ((int(h) * 60 + int(mi)) * 60 + int(se)) * 1000 + int(ms.ljust(3, "0"))


def format_time(ms: int) -> str:
    ms = max(0, int(ms))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, milli = divmod(rem, 1000)
    return f"{h:02}:{m:02}:{s:02},{milli:03}"


def parse_srt(content: str) -> list[Segment]:
    content = content.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    out: list[Segment] = []
    for block in re.split(r"\n\s*\n", content.strip()):
        lines = block.split("\n")
        if not lines or not lines[0].strip():
            continue
        i = 0
        if "-->" not in lines[0]:
            i = 1
        if i >= len(lines):
            raise SrtError(f"Incomplete block: {block[:40]!r}")
        m = LINE_RE.match(lines[i])
        if not m:
            raise SrtError(f"Missing timestamp line in block: {block[:40]!r}")
        start, end = parse_time(m.group(1)), parse_time(m.group(2))
        if end <= start:
            raise SrtError(f"End must be after start: {lines[i]!r}")
        out.append(Segment(len(out) + 1, start, end, "\n".join(lines[i + 1:]).strip()))
    if not out:
        raise SrtError("No subtitle segments found")
    return out


def to_srt(segments: list[Segment]) -> str:
    return "\n".join(
        f"{n}\n{format_time(s.start_ms)} --> {format_time(s.end_ms)}\n{s.text}\n"
        for n, s in enumerate(segments, 1)
    )
