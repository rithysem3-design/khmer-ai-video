"""Build an ASS subtitle file so style + position are reproduced when burned in with FFmpeg.

Normalized coordinates (0..1) from the app are converted to pixel positions.
Limitation: ASS cannot draw rounded corners; background uses a square opaque box (BorderStyle=3).
"""
from dataclasses import dataclass

from .srt import Segment


@dataclass
class Style:
    font: str = "Noto Sans Khmer"
    size: float = 0.05          # fraction of video height
    color: str = "#FFFFFF"
    bold: bool = False
    bg_enabled: bool = False
    bg_color: str = "#000000"
    bg_opacity: float = 0.6     # 0 transparent .. 1 opaque
    outline: float = 2.0
    x: float = 0.5              # normalized center
    y: float = 0.88


def _bgr(hex_color: str, alpha: float = 1.0) -> str:
    h = hex_color.lstrip("#")
    if len(h) != 6:
        raise ValueError("color must be #RRGGBB")
    r, g, b = h[0:2], h[2:4], h[4:6]
    a = int(round((1 - max(0.0, min(1.0, alpha))) * 255))
    return f"&H{a:02X}{b}{g}{r}".upper()


def _t(ms: int) -> str:
    cs = ms // 10
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02}:{s:02}.{cs:02}"


def build_ass(segments: list[Segment], st: Style, width: int, height: int) -> str:
    if width <= 0 or height <= 0:
        raise ValueError("invalid video size")
    st.x = max(0.0, min(1.0, st.x))
    st.y = max(0.0, min(1.0, st.y))
    size = max(8, int(st.size * height))
    border_style = 3 if st.bg_enabled else 1
    back = _bgr(st.bg_color, st.bg_opacity) if st.bg_enabled else "&H00000000"
    outline_col = back if st.bg_enabled else "&H00000000"
    head = (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {width}\nPlayResY: {height}\nWrapStyle: 0\n\n"
        "[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,"
        "BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,"
        "Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
        f"Style: Default,{st.font},{size},{_bgr(st.color)},&H000000FF,{outline_col},{back},"
        f"{-1 if st.bold else 0},0,0,0,100,100,0,0,{border_style},{st.outline if not st.bg_enabled else 6},"
        "0,5,10,10,10,1\n\n"
        "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n"
    )
    px, py = int(st.x * width), int(st.y * height)
    lines = []
    for s in segments:
        text = s.text.replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", "\\N")
        lines.append(f"Dialogue: 0,{_t(s.start_ms)},{_t(s.end_ms)},Default,,0,0,0,,{{\\pos({px},{py})}}{text}")
    return head + "\n".join(lines) + "\n"
