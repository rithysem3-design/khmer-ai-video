import json
import os
import subprocess


def probe(path: str) -> dict:
    r = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format",
                        "-show_streams", path], capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        raise ValueError("Not a valid media file")
    d = json.loads(r.stdout)
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), None)
    if not v:
        raise ValueError("No video stream found")
    return {"width": int(v["width"]), "height": int(v["height"]),
            "duration": float(d["format"].get("duration", 0))}


def _esc_filter_path(p: str) -> str:
    return p.replace("\\", "/").replace(":", "\\:").replace("'", "\\'")


def burn(video: str, ass: str, out: str, audio: str | None = None,
         orig_vol: float = 1.0, voice_vol: float = 1.0, crf: int = 23, fonts_dir: str | None = None):
    vf = f"ass='{_esc_filter_path(ass)}'" + (f":fontsdir='{_esc_filter_path(fonts_dir)}'" if fonts_dir else "")
    cmd = ["ffmpeg", "-y", "-i", video]
    if audio:
        cmd += ["-i", audio, "-filter_complex",
                f"[0:a]volume={orig_vol}[o];[1:a]volume={voice_vol}[v];[o][v]amix=inputs=2:normalize=0[a]",
                "-map", "0:v", "-map", "[a]"]
    else:
        cmd += ["-map", "0:v", "-map", "0:a?"]
    cmd += ["-vf", vf, "-c:v", "libx264", "-crf", str(int(crf)), "-preset", "veryfast",
            "-c:a", "aac", out]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if r.returncode != 0:
        raise RuntimeError("FFmpeg export failed: " + r.stderr[-300:])
    if not os.path.exists(out) or os.path.getsize(out) == 0:
        raise RuntimeError("Export produced no file")
    probe(out)  # verify playable
